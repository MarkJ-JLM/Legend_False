﻿using System.Collections.Generic;

namespace Nml.Improve.Me.Dependencies
{
	public class Product
	{
		public IEnumerable<Fund> Funds { get; set; }
	}
}