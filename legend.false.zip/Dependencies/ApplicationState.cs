﻿namespace Nml.Improve.Me.Dependencies
{
	public enum ApplicationState
	{
		Pending,
		Activated,
		InReview,
		Closed
	}
}