﻿namespace Nml.Improve.Me.Dependencies
{
	public enum HeaderRepeat
	{
		FirstPageOnly
	}
}