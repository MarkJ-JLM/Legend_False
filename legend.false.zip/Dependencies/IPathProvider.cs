﻿namespace Nml.Improve.Me.Dependencies
{
	public interface IPathProvider
	{
		string Get(string target);
	}
}